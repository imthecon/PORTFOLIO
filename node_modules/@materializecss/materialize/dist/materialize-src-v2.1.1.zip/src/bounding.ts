export class Bounding {
  left: number; // left offset coordinate
  top: number;
  width: number;
  height: number;
}
