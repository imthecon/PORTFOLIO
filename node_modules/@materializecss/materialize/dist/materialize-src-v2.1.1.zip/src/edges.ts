export class Edges {
  top: boolean; // If the top edge was exceeded
  right: boolean; // If the right edge was exceeded
  bottom: boolean; // If the bottom edge was exceeded
  left: boolean; // If the left edge was exceeded
}
